const main = require('../main/main');

describe('main()', () => {
  
});