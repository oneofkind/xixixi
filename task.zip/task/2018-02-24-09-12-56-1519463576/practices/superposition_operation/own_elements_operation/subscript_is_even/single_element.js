'use strict';
function array_contain(array, obj) {
  var count = 0;
  for (var i = 0; i < array.length; i++) {
    if (array[i] == obj) {
      count++;
    }
  }
  return count;
}
var single_element = function (collection) {
  var middleResult = [];
  for (var i = 0; i < collection.length; i++) {
    if ((i + 1) % 2 == 0) {
      middleResult.push(collection[i]);
    }
  }
  var finalResult = [];
  for (var i = 0;i<middleResult.length;i++) {
    if (array_contain(middleResult, middleResult[i]) == 1) {
      finalResult.push(middleResult[i]);
    }
  }
  sort(finalResult);
  return finalResult;
};

function sort(arr){
  for(var i = 0;i < arr.length-1;i++){
    for(var j =0;j<arr.length-i-1;j++){
      if(arr[j]>arr[j+1]){
        var t = arr[j];
        arr[j] = arr[j+1];
        arr[j+1] = t;
      }
    }
  }

}
module.exports = single_element;
