'use strict';
var number_map_to_word = function(collection){
  return ['a','b','c','d','e'];
};

module.exports = number_map_to_word;
